document.addEventListener("DOMContentLoaded", function () {
    const balanceEl = document.getElementById("balance");
    const paymentBtn = document.getElementById("paymentBtn");
//    const depositBtn = document.getElementById("depositBtn");
    const paymentModal = document.getElementById("paymentModal");
    //const depositModal = document.getElementById("depositModal");
    const cancelPaymentBtn = document.getElementById("cancelPaymentBtn");
    const sendPaymentBtn = document.getElementById("sendPaymentBtn");
//    const cancelDepositBtn = document.getElementById("cancelDepositBtn");
//    const confirmDepositBtn = document.getElementById("confirmDepositBtn");
    const transactionsTable = document.getElementById("transactionTableBody");
    const account = document.getElementById("account");
    const viewHistoryBtn = document.getElementById("viewHistoryBtn");
    const recipientSelect = document.getElementById("recipient");
    //const depositRecipientSelect = document.getElementById("depositRecipient");



    //URLS
    const apiUrl = "/apiDebit/updateDbBalance";
//    const apiUrl1 = "/apiDebit/getAllDebit";

    const members = ["Alice", "Bob", "Charlie", "David", "Emma", "Frank", "Grace", "Helen", "Ian", "Jack"];
//    const loggedInUser = "Alice";
//
//    // Set welcome message
    //document.getElementById("welcomeMessage").innerText = `Welcome To Federal Bank, ${loggedInUser}!`;
//
   // Populate recipient dropdowns
//    members.forEach(member => {
//    if (member !== loggedInUser) {
//    recipientSelect.add(new Option(member, member));
//    //depositRecipientSelect.add(new Option(member, member));
//    }
});

    // Event Listeners
    paymentBtn.addEventListener("click", () => toggleModal(paymentModal, true));
    //depositBtn.addEventListener("click", () => toggleModal(depositModal, true));
    cancelPaymentBtn.addEventListener("click", () => toggleModal(paymentModal, false));
    //cancelDepositBtn.addEventListener("click", () => toggleModal(depositModal, false));

    sendPaymentBtn.addEventListener("click", handleSendPayment);
//    confirmDepositBtn.addEventListener("click", handleDepositFunds);
//    viewHistoryBtn.addEventListener("click", displayTransactions);

    // Initialize transactions
//    displayTransactions();

    // Function to open/close modal
    function toggleModal(modal, show) {
        modal.style.display = show ? "block" : "none";
    }

    function handleSendPayment() {
        const amount = parseFloat(document.getElementById("amount").value);
        const fromAccount = parseInt(document.getElementById("fromAccount").value);
        const toAccount = parseInt(document.getElementById("toAccount").value);
        const recipientSelect = document.getElementById("recipient"); // Assuming it's a select element
        const recipient = recipientSelect.value;
        const bankName = document.getElementById("bankName").value.trim();

        if (validateTransaction(amount, bankName)) {
            const transaction = createTransaction(amount, fromAccount, toAccount);

            fetch(apiUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(transaction),
            })
            .then(response => response.text())
            .then(data => {
                //balanceEl.textContent = `$${parseFloat(updatedAmount).toFixed(2)}`;
//                alert("Payment Successful!");
               // const type = "Debit";
              //  addTransactionRow(type, account, amount);
                toggleModal(paymentModal, false);
                //Reload DOM
                //document.addEventListener("DOMContentLoaded", function () {
                //   initializeApp();
                //});
              document.getElementById("transactionTableBody").style.display = "none";
               redisplayTransactions();
            })
            .catch(error => console.error("Error processing payment:", error));
        }

//        // Fetch transactions after payment processing
//        fetch(apiUrl1, {
//            method: "GET",
//            headers: { "Content-Type": "application/json" },
//        })
//        .then(response => response.json())
//        .then(transactions => {
//            transactionsTable.innerHTML = "";
//
//            if (!transactions || transactions.length === 0) {
//                transactionsTable.innerHTML = "<tr><td colspan='6'>No transactions found</td></tr>";
//                return;
//            }
//
//            transactions.forEach(transaction => {
//                const row = `
//                    <tr>
//                        <td>${new Date(transaction.date).toLocaleString()}</td>
//                        <td class="${transaction.type.toLowerCase()}">${transaction.type}</td>
//                        <td>XXXXX</td>
//                        <td>${transaction.account}</td>
//                        <td class="${transaction.type.toLowerCase()}">${transaction.type === "Debit" ? "-" : "+"}$${Math.abs(transaction.amount).toFixed(2)}</td>
//                        <td>${transaction.bank}</td>
//                    </tr>`;
//                transactionsTable.innerHTML += row;
//            });
//        })
//        .catch(error => {
//            console.error("Error fetching transactions:", error);
//            transactionsTable.innerHTML = "<tr><td colspan='6'>Error loading transactions</td></tr>";
//        });
    }


    // Handle Deposit Funds
   /*function handleDepositFunds() {
       const amount = parseFloat(document.getElementById("depositAmount").value);
       const recipient = depositRecipientSelect.value;
       const bankName = document.getElementById("depositBankName").value.trim();

       if (validateTransaction(amount, bankName)) {
           const transaction = createTransaction(amount, account);

           fetch(apiUrl, {
               method: "POST",
               headers: { "Content-Type": "application/json" },
               body: JSON.stringify(transaction),
           })
           .then(response => response.json())
           .then(updatedAmount => {
               // After getting the updated balance from the backend, update the balance on the UI
               balanceEl.textContent = `$${parseFloat(updatedAmount).toFixed(2)}`; // This will show the updated balance on the UI
               alert("Deposit Successful!");
               updateBalance(amount, recipient, bankName, "Credit", updatedAmount);
               toggleModal(depositModal, false);
           })
           .catch(error => console.error("Error processing deposit:", error));
       }
   }*/

    // Validate transaction fields
    function validateTransaction(amount, bankName) {
        if (isNaN(amount) || amount <= 0 || !bankName.trim()) {
            alert("Invalid amount or missing bank name.");
            return false;
        }
        return true;
    }

    // Create transaction object
    function createTransaction(amount, fromAccount, toAccount) {
        return {
            amount,
            fromAccount,
            toAccount
        };
    }

    function addTransactionRow(type, account, amount) {
        // Check if 'data' is a number before calling toFixed
//        if (typeof data === 'number') {
            // Update balance display
//            if (balanceEl) {
//                balanceEl.textContent = `$${data.toFixed(2)}`; // This will show the updated balance on the UI
////            }
//        } else {
//            console.error("Invalid data format: expected a number.");
//        }

        // Add the transaction row to the transactions table
        const row = `
            <tr>
                <td></td>
                <td class="${type.toLowerCase()}">${type}</td>
                <td>${account}</td>
                <td></td>
                <td class="${type.toLowerCase()}">${type === "Debit" ? "-" : "+"}$${Math.abs(amount).toFixed(2)}</td>
                <td>${formatDate(new Date())}</td>
            </tr>`;
        transactionsTable.innerHTML += row;
    }

    // Save transaction to localStorage
    function saveTransaction(transaction) {
        const transactions = JSON.parse(localStorage.getItem("transactions")) || [];
        transactions.push(transaction);
        localStorage.setItem("transactions", JSON.stringify(transactions));
        displayTransactions();
    }

//    // Display stored transactions
//    function displayTransactions() {
//        transactionsTable.innerHTML = "";
//        const transactions = JSON.parse(localStorage.getItem("transactions")) || [];
//        transactions.forEach(transaction => {
//            const row = `
//                <tr>
//                    <td>${transaction.date}</td>
//                    <td class="${transaction.type.toLowerCase()}">${transaction.type}</td>
//                    <td>XXXXX</td>
//                    <td>${transaction.account}</td>
//                    <td class="${transaction.type.toLowerCase()}">${transaction.type === "Debit" ? "-" : "+"}$${Math.abs(transaction.amount)}</td>
//                    <td>${transaction.bank}</td>
//                </tr>`;
//            transactionsTable.innerHTML += row;
//        });
//    }

    // Format date
    function formatDate(date) {
        return date.toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        });
    }

    function redisplayTransactions(){
    fetch(`http://localhost:8081/users/getAllTransactions/${loggedInUser}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (!data || data.length === 0) {
                        console.warn("No transactions found for user.");
                        return;
                    }

                    const tableBody2 = document.getElementById("transactionTable2Body");

                    data.forEach(transaction => {
                        const row = document.createElement("tr");
                        const isDebit = transaction.paymentType.toLowerCase() === "debit";

                        row.innerHTML = `
                            <td>${transaction.transactionId}</td>
                            <td>${transaction.paymentType}</td>
                            <td>${transaction.bankIfsc}</td>
                            <td>${transaction.accountHolderName}</td>
                            <td>${transaction.bankName}</td>
                            <td class="${isDebit ? "debit" : "credit"}">
                                ${isDebit
                                    ? `-$${transaction.debitedAmount.toFixed(2)}`
                                    : `+$${transaction.creditedAmount.toFixed(2)}`
                                }
                            </td>
                            <td>${new Date(transaction.timestamp).toLocaleString()}</td>
                        `;

                        tableBody2.appendChild(row);
                        const balanceEls = document.getElementById("balance");
                        if (data.length > 0) {
                        var latestBalance = data[0].amount;
                        balanceEls.textContent = `$${parseFloat(latestBalance).toFixed(2)}`;
                        }
                    });
                })
                .catch(error => console.error("Error fetching transactions:", error));
    }
});