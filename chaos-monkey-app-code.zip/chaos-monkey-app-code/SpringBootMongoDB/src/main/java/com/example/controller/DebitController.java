package com.example.controller;

//import com.example.exception.BalanceInsufficientException;
import com.example.exception.BalanceInsufficientException;
import com.example.model.*;
import com.example.repository.AccountRepository;
import com.example.repository.DebitRepository;
import com.example.repository.TransactionRepo;
import com.example.service.ProductDbService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

//@Slf4j
@RestController
@RequestMapping("/apiDebit")
//@CrossOrigin(origins = "http://localhost:63342")
public class DebitController {

    @Autowired
    DebitRepository debitRepository;

    @Autowired
    TransactionRepo transactionRepo;

    @Autowired
    ProductDbService productDbService;

    @Autowired
    AccountRepository accountRepository;

    UpdateObject updateObject;

    @Autowired
    private MongoTemplate mongoTemplate;
    private static final Logger log = LoggerFactory.getLogger(DebitController.class.getName());

    @GetMapping("/getAllDebit")
    public ResponseEntity<List<Debit>> getAllDebits() {
        try {
            List<Debit> debits = debitRepository
                    .findAll(PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "date")))
                    .getContent(); // Fetch only the latest 10 records

            if (debits.isEmpty()) {
                return ResponseEntity.noContent().build();
            }
            return ResponseEntity.ok(debits);
        } catch (Exception e) {
            log.error("Error fetching latest 10 transactions", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping(value = "/createDebit")
    public ResponseEntity<Debit> createDebit(@RequestBody Debit debit) {
        log.info("Creating debit: {}", debit);
        debitRepository.save(debit);
        return new ResponseEntity<>(debit, HttpStatus.OK);
    }

    @GetMapping("/getTransaction/{fromAcct}")
    public ResponseEntity<?> getTransactionByAcctnum(@PathVariable("fromAcct") String fromAcct) {
        String toRoute = "9099791700";
        List<Transaction> transactions = productDbService.getransaction(fromAcct, toRoute);

        if (transactions.isEmpty()) {
            log.warn("No transactions found for account: {}", fromAcct);
            return new ResponseEntity<>("Transaction not found", HttpStatus.NOT_FOUND);
        }

        Optional<Transaction> transDataOptional = transactions.stream()
                .max(Comparator.comparing(Transaction::getTimestamp));
        Transaction transactionDBObj = transDataOptional.orElse(null);

        if (transactionDBObj != null) {
            log.info("Fetched latest transaction with balance amount: {}", transactionDBObj.getAmount());
            return new ResponseEntity<>(transactionDBObj, HttpStatus.OK);
        }

        return new ResponseEntity<>("Transaction not found", HttpStatus.NOT_FOUND);
    }

    @GetMapping("/debits/{id}")
    public ResponseEntity<Debit> getDebitById(@PathVariable("id") String id) {
        log.info("Fetching debit with ID: {}", id);
        Optional<Debit> debitData = debitRepository.findById(id);

        if (debitData.isPresent()) {
            return new ResponseEntity<>(debitData.get(), HttpStatus.OK);
        } else {
            log.warn("No debit found with ID: {}", id);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping(value = "/updateDbBalance", consumes = "application/json")
    public ResponseEntity<?> updateDebitBalance(@RequestBody UpdateObject updateObject) throws JsonProcessingException, BalanceInsufficientException {
        log.info("Received request: Amount={}, FromAccount={}, ToAccount={}",
                updateObject.getAmount(), updateObject.getFromAccount(), updateObject.getToAccount());

        log.info("Received full request object: {}", updateObject);

        if (updateObject == null || updateObject.getFromAccount() == null || updateObject.getToAccount() == null) {
            log.error("Invalid request payload: {}", updateObject);
            return new ResponseEntity<>("Invalid request payload", HttpStatus.BAD_REQUEST);
        }

        String fromAcctNum = updateObject.getFromAccount();
        String toAccountNum = updateObject.getToAccount();
        double debitAmount = updateObject.getAmount();

        log.info("Updating debit balance from account: {} to account : {} of amount: {}", fromAcctNum, toAccountNum, debitAmount);

        // Fetch the balance amount
        double updatedBalance = 0.0;
        Optional<Accounts> accountOpt = accountRepository.findByAccountNumber(fromAcctNum);
        if(accountOpt.isPresent()) {
            Accounts singleAccount = accountOpt.get();
            double accountBalance = singleAccount.getAccountBalance();

//            //condition to check the balance
            if (accountBalance < debitAmount) {
                throw new BalanceInsufficientException(HttpStatus.BAD_REQUEST.value(), "The user doesn't have balance to proceed");
            }

            //Calculate the balance
            updatedBalance = accountBalance - debitAmount;
            //save balance to accounts
            accountRepository.updateAccountBalance(fromAcctNum, updatedBalance);

            Transaction debitTransaction = new Transaction();
            debitTransaction.setFromAccountNum(fromAcctNum);
            debitTransaction.setToAccountNum(toAccountNum);
            debitTransaction.setAmount(updatedBalance);
            debitTransaction.setDebitedAmount(debitAmount);
            debitTransaction.setTimestamp(new Date());
            debitTransaction.setPaymentType("DEBIT");

            transactionRepo.save(debitTransaction);
            log.info("Debit transaction saved successfully: {}", debitTransaction);
        }
        // Step 3: Call the Credit Service
        try {
            RestTemplate restTemplate = new RestTemplate();
            String creditServiceUrl = "http://localhost:8082/payment/updateCreditAmt"; // Update URL based on deployment

            // Create credit request payload
            Map<String, Object> creditRequest = new HashMap<>();
            creditRequest.put("fromAccount", fromAcctNum);
            creditRequest.put("toAccount", toAccountNum);
            creditRequest.put("amount", debitAmount);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(creditRequest, headers);

            ResponseEntity<String> creditResponse = restTemplate.exchange(creditServiceUrl, HttpMethod.POST, entity, String.class);

            if (creditResponse.getStatusCode() == HttpStatus.OK) {
                log.info("Credit successful for account: {}", toAccountNum);
            } else {
                log.error("Credit failed: {}", creditResponse.getBody());
            }
        } catch (Exception e) {
            log.error("Error while calling Credit Service: {}", e.getMessage());
        }

        return new ResponseEntity<>(updatedBalance, HttpStatus.OK);
    }

    @PostMapping("/debitsbal")
    public ResponseEntity<Integer> getDebitAmount(@RequestParam String fromAccountNum, @RequestParam String fromRoutingNum) {
        try {
            List<Debit> debits = debitRepository.findByFromAccountNumAndFromRoutingNum(fromAccountNum, fromRoutingNum);
            log.info("Fetched {} debit records", debits.size());

            double totalDebitedAmount = debits.stream().mapToDouble(Debit::getDebitedAmount).sum();
            log.info("Total debited amount: {}", totalDebitedAmount);

            return new ResponseEntity<>((int) totalDebitedAmount, HttpStatus.ACCEPTED);
        } catch (Exception e) {
            log.error("Error fetching debit amount", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/createTransaction")
    public ResponseEntity<Transaction> createTransaction(@RequestBody Transaction transaction) {
        log.info("Processing transaction: {}", transaction);

        // Assign a unique transaction ID
        transaction.setTransactionId(UUID.randomUUID().toString());
        transaction.setTimestamp(Date.from(Instant.now()));

        // Handle DEBIT & CREDIT separately
        if ("DEBIT".equalsIgnoreCase(transaction.getPaymentType())) {
            transaction.setDebitedAmount(transaction.getDebitedAmount());
            transaction.setCreditedAmount(null);
        } else if ("CREDIT".equalsIgnoreCase(transaction.getPaymentType())) {
            transaction.setCreditedAmount(transaction.getCreditedAmount());
            transaction.setDebitedAmount(null);
        } else {
            log.error("Invalid transaction type: {}", transaction.getPaymentType());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        Transaction savedTransaction = transactionRepo.save(transaction);
        log.info("Transaction created successfully: {}", savedTransaction);
        return new ResponseEntity<>(savedTransaction, HttpStatus.CREATED);
    }

    @PostMapping("/updateCreditAmt")
    public ResponseEntity<String> updateCreditAmt(@RequestBody Map<String, Object> request) {
        String fromAccount = (String) request.get("fromAccount");
        String toAccount = (String) request.get("toAccount");
        Double creditAmount = Double.valueOf(request.get("amount").toString());

        log.info("Received credit request from {} to {}", fromAccount, toAccount);

        productDbService.addCreditRecord(fromAccount, toAccount, creditAmount);

        return new ResponseEntity<>("Amount credited successfully", HttpStatus.OK);
    }
}
