package com.example.repository;

import com.example.model.Transaction;
import com.example.model.Users;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;


public interface UserRepository extends MongoRepository<Users, String> {
    List<Transaction> findTransactionsByUsername(String username); // Correct field name

    Optional<Users> findByUsername(String userName);

}

