package com.example.repository;

import com.example.model.Bank;
import com.example.model.BankDetailsDTO;
import com.example.model.Transaction;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BankRepository extends MongoRepository<Bank, String> {

    @Aggregation(pipeline = {
            "{ $lookup: { from: 'Transaction', localField: 'toAccountNum', foreignField: 'fromAccountNum', as: 'Transaction' } }",
            "{ $unwind: { path: '$Transaction', preserveNullAndEmptyArrays: true } }",
            "{ $match: { 'toAccountNum': ?0 } }",
            "{ $project: { _id: 0, bank_ifsc: 1, bank_name: 1, account_holder_name: 1 } }",
            "{ $group: { _id: { bank_ifsc: '$bank_ifsc', bank_name: '$bank_name', account_holder_name: '$account_holder_name' } } }",
            "{ $project: { _id: 0, bank_ifsc: '$_id.bank_ifsc', bank_name: '$_id.bank_name', account_holder_name: '$_id.account_holder_name' } }"

            })

    BankDetailsDTO findBankByFromAccountNum(String fromAccountNum);

    BankDetailsDTO findBankByToAccountNum(String toAccountNum);

    Bank findByToAccountNum(String toAccountNum);
}
