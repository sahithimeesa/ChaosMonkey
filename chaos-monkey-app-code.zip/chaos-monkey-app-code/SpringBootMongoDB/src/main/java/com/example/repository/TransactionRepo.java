package com.example.repository;

import com.example.model.Transaction;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface TransactionRepo extends MongoRepository<Transaction, String> {

    List<Transaction> findByFromAccountNumAndToAccountNum(String fromAccountNum, String toAccountNum);

    @Aggregation(pipeline = {
            "{ $lookup: { from: 'accounts', localField: 'fromAccountNum', foreignField: 'accountNumber', as: 'account' } }",
            "{ $unwind: { path: '$account', preserveNullAndEmptyArrays: true } }",
            "{ $lookup: { from: 'users', localField: 'userId', foreignField: 'userId', as: 'user' } }",
            "{ $unwind: { path: '$user', preserveNullAndEmptyArrays: true } }",
            "{ $match: { 'user.userName': ?0 } }",
            "{ $project: { transaction_id: 1, fromAccountNum: 1, fromRoutingNum: 1, toAccountNum: 1, toRoutingNum: 1, timestamp: 1, debitedAmount: 1, creditedAmount: 1, paymentType: 1 } }"
    })
    List<Transaction> findTransactionsByUserName(String userName);

    List<Transaction> findByFromAccountNumOrToAccountNumOrderByTimestampDesc(String fromAccountNum, String toAccountNum, Pageable pageable);


}
