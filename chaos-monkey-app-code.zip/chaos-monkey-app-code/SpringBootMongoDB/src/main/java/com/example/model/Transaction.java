/*
 * Copyright 2020, Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

import java.time.Instant;
import java.util.Date;
import java.util.UUID;

/**
 * Defines a banking transaction.
 - *
 * Timestamped at object creation time.
 */
@ToString
@Getter
@Setter
@EqualsAndHashCode
@AllArgsConstructor

@Document(collection = "Transaction")
public final class Transaction {
    @Id
    @Indexed(unique = true)
    private String transaction_id;

    public Transaction() {
        this.transaction_id = UUID.randomUUID().toString(); // Generate a UUID on object creation
    }


    @Field(name = "fromAccountNum", targetType = FieldType.STRING)
    @JsonProperty("fromAccountNum")
    private String fromAccountNum;

    @Field(name = "fromRoutingNum", targetType = FieldType.STRING)
    @JsonProperty("fromRoutingNum")
    private String fromRoutingNum;

    @Field(name = "toAccountNum", targetType = FieldType.STRING)
    @JsonProperty("toAccountNum")
    private String toAccountNum;

    @Field(name = "toRoutingNum", targetType = FieldType.STRING)
    @JsonProperty("toRoutingNum")
    private String toRoutingNum;

    @Field(name = "amount", targetType = FieldType.DOUBLE)
    @JsonProperty("amount")
    private Double amount;

    @Field(name = "timestamp", targetType = FieldType.DATE_TIME)

    @JsonProperty("timestamp")
    private Date timestamp=  Date.from(Instant.now());

    @Field(name = "debitedAmount", targetType = FieldType.DOUBLE)
    private Double debitedAmount;
    @Field(name = "creditedAmount", targetType = FieldType.DOUBLE)
    private Double creditedAmount;

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPaymentType() {
        return paymentType;
    }



    public void setTransactionType(String transactionType) {
        this.paymentType = transactionType;
    }

    @Field(name = "paymentType", targetType = FieldType.STRING)
    private String paymentType;


    private static final double CENTS_PER_DOLLAR = 100.0;


    public String getFromAccountNum() {
        return fromAccountNum;
    }

    public String getFromRoutingNum() {
        return fromRoutingNum;
    }

    public String getToAccountNum() {
        return toAccountNum;
    }

    public String getToRoutingNum() {
        return toRoutingNum;
    }

    public Double getAmount() {
        return amount;
    }

    public void setTransactionId(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public void setFromAccountNum(String fromAccountNum) {
        this.fromAccountNum = fromAccountNum;
    }

    public void setFromRoutingNum(String fromRoutingNum) {
        this.fromRoutingNum = fromRoutingNum;
    }

    public void setToAccountNum(String toAccountNum) {
        this.toAccountNum = toAccountNum;
    }

    public void setToRoutingNum(String toRoutingNum) {
        this.toRoutingNum = toRoutingNum;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public Double getDebitedAmount() {
        return debitedAmount;
    }

    public void setDebitedAmount(Double debitedAmount) {
        this.debitedAmount = debitedAmount;
    }

    public Double getCreditedAmount() {
        return creditedAmount;
    }

    public void setCreditedAmount(Double creditedAmount) {
        this.creditedAmount = creditedAmount;
    }


}
 