package com.example.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Document(collection = "bank")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Bank {

    @Id
    @Field(name = "bank_id", targetType = FieldType.STRING)
    @JsonProperty("id")
    private String id;

    @Field(name = "bank_name", targetType = FieldType.STRING)
    @JsonProperty("bankName")
    private String bankName;

    @Field(name = "bank_ifsc", targetType = FieldType.STRING)
    @JsonProperty("bankIfsc")
    private String bankIfsc;

    public String getBankBranch() {
        return bankBranch;
    }

    public void setBankBranch(String bankBranch) {
        this.bankBranch = bankBranch;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankIfsc() {
        return bankIfsc;
    }

    public void setBankIfsc(String bankIfsc) {
        this.bankIfsc = bankIfsc;
    }

    public String getToAccountNum() {
        return toAccountNum;
    }

    public void setToAccountNum(String toAccountNum) {
        this.toAccountNum = toAccountNum;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    @Field(name = "bank_branch", targetType = FieldType.STRING)
    @JsonProperty("bankBranch")
    private String bankBranch;

    @Field(name = "toAccountNum", targetType = FieldType.STRING)
    @JsonProperty("toAccountNum")
    private String toAccountNum;


    @Field(name = "account_holder_name", targetType = FieldType.STRING)
    @JsonProperty("accountHolderName")
    private String accountHolderName;
}
