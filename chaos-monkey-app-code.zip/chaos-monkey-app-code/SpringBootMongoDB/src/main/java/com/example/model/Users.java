package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Document(collection = "users")
public class Users {

    @Id
    @Field(name = "user_id", targetType = FieldType.STRING)
    @JsonProperty("userId")
    private String userId;

    @Field(name = "user_name", targetType = FieldType.STRING)
    @JsonProperty("username")
    private String username;

    @Field(name = "password", targetType = FieldType.STRING)
    @JsonProperty("password")
    private String password;

    public Users(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
