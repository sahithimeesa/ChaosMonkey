package com.example.service;

import com.example.model.AccountNumberDTO;
import com.example.model.Accounts;
import com.example.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AccountService {

    @Autowired
    private final AccountRepository accountRepository;

    @Autowired
    public AccountService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public Accounts saveAccount(Accounts account) {
        return accountRepository.save(account);
    }

    public List<Accounts> saveAllAccounts(List<Accounts> accounts) {
        return accountRepository.saveAll(accounts);
    }
    public Accounts createOrUpdateAccount(String accountNumber, String accountType, String userId, double balance) {
        Optional<Accounts> optionalAccount = accountRepository.findByAccountNumber(accountNumber);
        if (optionalAccount.isPresent()) {
            // Update existing account
            Accounts existingAccount = optionalAccount.get();
            existingAccount.setAccountBalance(existingAccount.getAccountBalance() + balance);
            double updatedBalance = existingAccount.getAccountBalance() + balance;
            accountRepository.updateAccountBalance(accountNumber, updatedBalance);
            return existingAccount;
        } else {
            // Create new account
            Accounts newAccount = new Accounts();
            newAccount.setAccountNumber(accountNumber);
            newAccount.setAccountType(accountType);
            newAccount.setUserId(userId);
            newAccount.setAccountBalance(balance);
            return accountRepository.save(newAccount);
        }
    }
    public List<String> getAccountsByUsername(String userName) {
        List<AccountNumberDTO> accountList = accountRepository.findAccountNumbersByUsername(userName);

        return accountList.stream()
                .map(AccountNumberDTO::getAccount_number)
                .collect(Collectors.toList());
    }
}