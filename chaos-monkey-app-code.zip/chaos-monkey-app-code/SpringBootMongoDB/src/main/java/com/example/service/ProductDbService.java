package com.example.service;

import com.example.model.Accounts;
import com.example.model.Debit;
import com.example.model.Transaction;
import com.example.repository.AccountRepository;
import com.example.repository.DebitRepository;
import com.example.repository.TransactionRepo;
import com.mongodb.client.result.UpdateResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;


import java.util.*;


@Service
public class ProductDbService {

    @Autowired
    private DebitRepository debitRepository;

    @Autowired
    private TransactionRepo transactionRepo;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private AccountRepository accountRepository;

    private static final Logger log = LoggerFactory.getLogger(ProductDbService.class.getName());

    public void updateTransactionAmount(String fromAcct, Double amount) {
        Query query = new Query(Criteria.where("fromAccountNum").is(fromAcct));
        Update update = new Update().set("amount", amount);

        UpdateResult result = mongoTemplate.updateFirst(query, update, Transaction.class);
        System.out.println("Modified Count: " + result.getModifiedCount());
    }



    @Autowired
    public ProductDbService(DebitRepository debitRepository, TransactionRepo transactionRepo ) {
        this.debitRepository = debitRepository;
        this.transactionRepo = transactionRepo;
    }
    public List<Transaction> getAllTransaction() {
        return transactionRepo.findAll();
    }
    public void addTransaction(Transaction transacction) {
        transactionRepo.save(transacction);
    }
    public void addDebit(String frmAccount, String frmRoute, double debitAmount) {
        Debit transaction = new Debit();
        transaction.setToAccountNum("0");
        transaction.setToRoutingNum("0");
        transaction.setFromAccountNum(frmAccount);
        transaction.setFromRoutingNum(frmRoute);

        transaction.setAmount(0);
        transaction.setDebitedAmount(debitAmount);
        debitRepository.save(transaction);
    }

    public List<Transaction> getransaction(String fromAcctNum, String toAccountNum) {
        List<Transaction> transact = new ArrayList<Transaction>();
        System.out.println("frm Acct " + fromAcctNum.trim());
        fromAcctNum=fromAcctNum.trim();
        toAccountNum=toAccountNum.trim();
        System.out.println("frmRout  " + toAccountNum);
        //transact = Collections.singletonList(transactionRepo.findByFromAccountNumAndFromRoutingNum(fromAcct, frmRoutingNum));
        transact = transactionRepo.findByFromAccountNumAndToAccountNum(fromAcctNum, toAccountNum);
        return transact;
    }

    public Page<Transaction> getAllTransactions(Pageable pageable) {
        return transactionRepo.findAll(pageable);
    }

    public Integer findDebitedAmount(String  id, String routingNum ) {
        return debitRepository.findDebitedAmount(id, routingNum);
    }

    public void addCreditRecord(String fromAccount, String toAccount, Double creditAmount) {
        log.info("Crediting amount {} from account {} to account {}", creditAmount, fromAccount, toAccount);

        double updatedBalance = 0.0;
        Optional<Accounts> accountOpt = accountRepository.findByAccountNumber(toAccount);
        if(accountOpt.isPresent()) {
            Accounts singleAccount = accountOpt.get();
            double accountBalance = singleAccount.getAccountBalance();
            //Calculate the balance
            updatedBalance = accountBalance + creditAmount;
            //save balance to accounts
            accountRepository.updateAccountBalance(toAccount, updatedBalance);
        }

        // Create a new credit transaction
        Transaction creditTransaction = new Transaction();
        creditTransaction.setFromAccountNum(fromAccount);
        creditTransaction.setToAccountNum(toAccount);
        creditTransaction.setAmount(updatedBalance);
        creditTransaction.setCreditedAmount(creditAmount);
        creditTransaction.setDebitedAmount(0.0);
        creditTransaction.setFromRoutingNum("0");
        creditTransaction.setToRoutingNum("0");
        creditTransaction.setTimestamp(new Date());
        creditTransaction.setPaymentType("CREDIT");

        // Add the credit transaction in PostgreSQL
        transactionRepo.save(creditTransaction);

        log.info("Credit transaction saved successfully: {}", creditTransaction);
    }
}
