package com.example.model;

import lombok.*;

@ToString
@EqualsAndHashCode
@AllArgsConstructor
public class UpdateObject {
    private double amount;

    private String fromAccount;

    private String toAccount;

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getFromAccount() {
        return fromAccount;
    }

    public void setFromAccount(String fromAccount) {
        this.fromAccount = fromAccount;
    }

    public String getToAccount() {
        return toAccount;
    }

    public void setToAccount(String toAccount) {
        this.toAccount = toAccount;
    }
}