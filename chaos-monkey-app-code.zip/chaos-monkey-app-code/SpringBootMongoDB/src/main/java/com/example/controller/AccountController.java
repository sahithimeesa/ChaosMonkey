package com.example.controller;

import com.example.model.Accounts;
import com.example.model.BankDetailsDTO;
import com.example.model.Transaction;
import com.example.model.TransactionHistory;
import com.example.repository.BankRepository;
import com.example.repository.TransactionRepo;
import com.example.service.AccountService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/accounts")
@Slf4j
public class AccountController {

    private final AccountService accountService;

    @Autowired
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @Autowired
    private BankRepository bankRepository;
    @Autowired
    private TransactionRepo transactionRepo;

    @PostMapping("/save")
    public Accounts saveAccount(@RequestBody Accounts account) {
        log.info("Received request to save account: {}", account);
        //Check if account exists
        Accounts savedAccount = accountService.createOrUpdateAccount(
                account.getAccountNumber(),
                account.getAccountType(),
                account.getUserId(),
                account.getAccountBalance()
        );
        log.info("Account saved successfully: {}", savedAccount);
        return savedAccount;
    }

    @PostMapping("/saveAll")
    public List<Accounts> saveAllAccounts(@RequestBody List<Accounts> accounts) {
        log.info("Received request to save multiple accounts: {}", accounts);
        List<Accounts> savedAccounts = accountService.saveAllAccounts(accounts);
        log.info("All accounts saved successfully.");
        return savedAccounts;
    }

    @GetMapping("/fetchAccountDetails/{user_name}")
    public ResponseEntity<?> fetchAccountDetailsByUsername(@PathVariable String user_name) {
        log.info("Fetching account details for username: {}", user_name);

        List<String> accountNumbers = accountService.getAccountsByUsername(user_name);

        if (accountNumbers.isEmpty()) {
            log.warn("No accounts found for username: {}", user_name);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No accounts found for username: " + user_name);
        }

        // Format the response as "Account Number: <value>"
        List<Map<String, String>> formattedResponse = accountNumbers.stream()
                .map(accNum -> Map.of("Account Number", accNum))
                .collect(Collectors.toList());

        return ResponseEntity.ok(formattedResponse);
    }

}
