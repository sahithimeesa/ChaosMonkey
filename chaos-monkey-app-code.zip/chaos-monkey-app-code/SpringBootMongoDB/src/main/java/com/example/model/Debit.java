package com.example.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;


import java.time.Instant;
import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Document(collection = "Debit")
public class Debit {
    @Id
    @Indexed(unique = true)
    private String transactionId;

    public Debit() {
        this.transactionId = UUID.randomUUID().toString(); // Generate a UUID on object creation
    }
    @Field(name = "fromAccountNum", targetType = FieldType.STRING)
    @JsonProperty("fromAccountNum")
    private String fromAccountNum;

    @Field(name = "fromRoutingNum", targetType = FieldType.STRING)
    @JsonProperty("fromRoutingNum")
    private String fromRoutingNum;
    @Field(name = "toAccountNum", targetType = FieldType.STRING)
    @JsonProperty("toAccountNum")
    private String toAccountNum;

    @Field(name = "toRoutingNum", targetType = FieldType.STRING)
    @JsonProperty("toRoutingNum")
    private String toRoutingNum;

    @Field(name = "amount", targetType = FieldType.INT32)
    @JsonProperty("amount")
    private Integer amount;
    @Field(name = "type", targetType = FieldType.STRING)
    @JsonProperty("type")
    private String type;

    @Field(name = "timestamp", targetType = FieldType.DATE_TIME)

    @JsonProperty("timestamp")
    private Date timestamp=  Date.from(Instant.now());

    @Field(name = "debitedAmount", targetType = FieldType.DOUBLE)
    private Double debitedAmount;

    private static final double CENTS_PER_DOLLAR = 100.0;


    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public void setFromAccountNum(String fromAccountNum) {
        this.fromAccountNum = fromAccountNum;
    }

    public void setFromRoutingNum(String fromRoutingNum) {
        this.fromRoutingNum = fromRoutingNum;
    }

    public void setToAccountNum(String toAccountNum) {
        this.toAccountNum = toAccountNum;
    }

    public void setToRoutingNum(String toRoutingNum) {
        this.toRoutingNum = toRoutingNum;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public Double getDebitedAmount() {
        return debitedAmount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDebitedAmount(Double debitedAmount) {
        this.debitedAmount = debitedAmount;
    }
}