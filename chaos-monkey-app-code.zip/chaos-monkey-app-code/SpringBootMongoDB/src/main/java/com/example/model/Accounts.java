package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

@Document(collection = "accounts")
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Accounts {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Field(name = "account_id", targetType = FieldType.STRING)
    @JsonProperty("accountId")
    private String accountId;

    @Field(name = "account_type", targetType = FieldType.STRING)
    @JsonProperty("accountType")
    private String accountType;


    @Indexed(unique = true)
    @Field(name = "account_number", targetType = FieldType.STRING)
    @JsonProperty("accountNumber")
    private String accountNumber;

    @Field(name = "user_id", targetType = FieldType.STRING)
    @JsonProperty("userId")
    private String userId;

    @Field(name = "account_balance", targetType = FieldType.STRING)
    @JsonProperty("accountBalance")
    private double accountBalance;

    public double getAccountBalance() {
        return accountBalance;
    }
    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }
}
