package com.example.repository;


import com.example.model.AccountNumberDTO;
import com.example.model.Accounts;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends MongoRepository<Accounts, String> {

    List<Accounts> findByUserId(String userId);
    Optional<Accounts> findByAccountNumber(String accountNumber);

    @Query("{'account_number' : ?0}")
    @Update("{'$set': {'account_balance': ?1}}")
    int updateAccountBalance(String accountNumber, double balance);

    @Aggregation(pipeline = {
            "{ $match: { accountType: 'savings', accountNumber: { $regex: /^[0-9]{12}$/ } } }",
            "{ $lookup: { from: 'users', localField: 'userId', foreignField: 'userId', as: 'user' } }",
            "{ $match: { user: { $ne: [] } } }",
            "{ $project: { _id: 0, balance: 1 } }"
    })
    List<Accounts> findSavingsAccountBalances();

    @Aggregation(pipeline = {
            "{ $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' } }",
            "{ $unwind: '$user' }",
            "{ $match: { 'user.user_name': ?0 } }",
            "{ $project: { _id: 0, account_number: 1} }"
    })
    String findAccountNumberByUserName(String username);


    @Aggregation(pipeline = {
            "{ $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' } }",
            "{ $unwind: '$user' }",
            "{ $match: { 'user.user_name': ?0 } }",
            "{ $project: { _id: 0, account_number: 1 } }"
    })
    List<AccountNumberDTO> findAccountNumbersByUsername(String userName);
}


