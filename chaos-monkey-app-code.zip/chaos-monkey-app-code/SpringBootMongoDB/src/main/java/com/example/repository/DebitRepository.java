package com.example.repository;

import com.example.model.Debit;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Repository
    public interface DebitRepository extends MongoRepository<Debit, String> {

    @Query("{ 'fromAccountNum' : ?0, 'fromRoutingNum' : ?1 }")
    Integer findDebitedAmount(String accountNum, String routeNum);

    List<Debit> findByFromAccountNumAndFromRoutingNum(String fromAccountNum, String routeNum);
}
