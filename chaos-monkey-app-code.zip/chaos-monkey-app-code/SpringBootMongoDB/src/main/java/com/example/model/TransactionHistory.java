package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

import java.time.Instant;
import java.util.UUID;

@Data
@NoArgsConstructor
public class TransactionHistory {

    @Id
    @Indexed(unique = true)
    @JsonProperty("transactionId")
    private String transactionId = UUID.randomUUID().toString();


    @Field(name = "beneAccountNum", targetType = FieldType.STRING)
    @JsonProperty("beneAccountNum")
    private String beneAccountNum;

    @Field(name = "amount", targetType = FieldType.DOUBLE)
    @JsonProperty("amount")
    private Double amount;

    @Field(name = "timestamp", targetType = FieldType.DATE_TIME)
    @JsonProperty("timestamp")
    private Instant timestamp = Instant.now();

    @Field(name = "bankName", targetType = FieldType.STRING)
    @JsonProperty("bankName")
    private String bankName;

    @Field(name = "bankIfsc", targetType = FieldType.STRING)
    @JsonProperty("bankIfsc")
    private String bankIfsc;

    @Field(name = "accountHolderName", targetType = FieldType.STRING)
    @JsonProperty("accountHolderName")
    private String accountHolderName;

    @Field(name = "debitedAmount", targetType = FieldType.DOUBLE)
    @JsonProperty("debitedAmount")
    private Double debitedAmount;

    @Field(name = "creditedAmount", targetType = FieldType.DOUBLE)
    @JsonProperty("creditedAmount")
    private Double creditedAmount;

    @Field(name = "paymentType", targetType = FieldType.STRING)
    @JsonProperty("paymentType")
    private String paymentType;
}
