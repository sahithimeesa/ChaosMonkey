package org.example.example.controller;


import org.example.example.model.Bank;
import org.example.example.service.BankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/banks")
public class BankController {

    @Autowired
    private BankService bankService;

    // Add a new bank
    @PostMapping("/add")
    public Bank addBank(@RequestBody Bank bank) {
        return bankService.saveBank(bank);
    }

    // Get all banks
    @GetMapping("/all")
    public List<Bank> getAllBanks() {
        return bankService.getAllBanks();
    }

    // Get a bank by ID
    @GetMapping("/{id}")
    public Optional<Bank> getBankById(@PathVariable String id) {
        return bankService.getBankById(id);
    }

    // Update a bank record
    @PutMapping("/{id}")
    public Bank updateBank(@PathVariable String id, @RequestBody Bank bank) {
        return bankService.updateBank(id, bank);
    }

    // Delete a bank by ID
    @DeleteMapping("/{id}")
    public String deleteBank(@PathVariable String id) {
        bankService.deleteBank(id);
        return "Bank with ID " + id + " deleted successfully.";
    }
}
