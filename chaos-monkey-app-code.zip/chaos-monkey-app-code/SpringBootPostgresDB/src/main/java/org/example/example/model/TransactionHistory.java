package org.example.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.stereotype.Indexed;


import java.time.Instant;
import java.util.UUID;

@Data
@NoArgsConstructor
public class TransactionHistory {

    @Id
    @JsonProperty("transactionId")
    @Column(name = "transaction_id", unique = true, nullable = false)
    private Long transactionId;

    @Column(name = "beneAccountNum")
    @JsonProperty("beneAccountNum")
    private String beneAccountNum;

    @Column(name = "amount")
    @JsonProperty("amount")
    private Double amount;

    @Column(name = "timestamp")
    @JsonProperty("timestamp")
    private Instant timestamp = Instant.now();

    @Column(name = "bankName")
    @JsonProperty("bankName")
    private String bankName;

    @Column(name = "bankIfsc")
    @JsonProperty("bankIfsc")
    private String bankIfsc;

    @Column(name = "accountHolderName")
    @JsonProperty("accountHolderName")
    private String accountHolderName;

    @Column(name = "debitedAmount")
    @JsonProperty("debitedAmount")
    private Double debitedAmount;

    @Column(name = "creditedAmount")
    @JsonProperty("creditedAmount")
    private Double creditedAmount;

    @Column(name = "paymentType")
    @JsonProperty("paymentType")
    private String paymentType;

    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public String getBeneAccountNum() {
        return beneAccountNum;
    }

    public void setBeneAccountNum(String beneAccountNum) {
        this.beneAccountNum = beneAccountNum;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankIfsc() {
        return bankIfsc;
    }

    public void setBankIfsc(String bankIfsc) {
        this.bankIfsc = bankIfsc;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public Double getDebitedAmount() {
        return debitedAmount;
    }

    public void setDebitedAmount(Double debitedAmount) {
        this.debitedAmount = debitedAmount;
    }

    public Double getCreditedAmount() {
        return creditedAmount;
    }

    public void setCreditedAmount(Double creditedAmount) {
        this.creditedAmount = creditedAmount;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }
}
