package org.example.example.repository;


import org.example.example.model.Bank;
import org.example.example.model.BankDetailsDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BankRepository extends JpaRepository<Bank, String> {

    @Query(value = "SELECT distinct b.bank_name, b.bank_ifsc, b.account_holder_name FROM banks b LEFT JOIN transactions t ON b.to_account_num = t.FROM_ACCT WHERE b.to_account_num = ?1", nativeQuery = true)
    List<Object[]> getBankDetailsByToAccountNum(String toAccountNum);

    BankDetailsDTO findBankByToAccountNum(String toAccountNum);

}
