package org.example.example.service;


import org.example.example.model.Bank;
import org.example.example.repository.BankRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BankService {

    @Autowired
    private BankRepository bankRepository;

    // Save a new bank
    public Bank saveBank(Bank bank) {
        return bankRepository.save(bank);
    }

    // Retrieve all banks
    public List<Bank> getAllBanks() {
        return bankRepository.findAll();
    }

    // Retrieve a bank by ID
    public Optional<Bank> getBankById(String id) {
        return bankRepository.findById(id);
    }

    // Update a bank by ID
    public Bank updateBank(String id, Bank updatedBank) {
        return bankRepository.findById(id).map(existingBank -> {
            existingBank.setBankName(updatedBank.getBankName());
            existingBank.setBankIfsc(updatedBank.getBankIfsc());
            existingBank.setBankBranch(updatedBank.getBankBranch());
            existingBank.setToAccountNum(updatedBank.getToAccountNum());
            existingBank.setAccountHolderName(updatedBank.getAccountHolderName());
            return bankRepository.save(existingBank);
        }).orElseThrow(() -> new RuntimeException("Bank with ID " + id + " not found"));
    }

    // Delete a bank by ID
    public void deleteBank(String id) {
        bankRepository.deleteById(id);
    }
}
