package org.example.example.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;

//import org.example.example.exception.BalanceInsufficientException;
import org.example.example.model.Accounts;
import org.example.example.model.Transaction;
import org.example.example.model.UpdateObject;
import org.example.example.repository.AccountRepository;
import org.example.example.repository.TransactionRepo;
import org.example.example.service.ProductDbService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;



import java.time.Instant;
import java.util.*;


@RestController
@RequestMapping("/payment")
public class TransactionController {
    private static final Logger log = LoggerFactory.getLogger(TransactionController.class.getName());
    @Autowired
    public final ProductDbService service;

    @Autowired
    RestTemplate restTemplate;
    @Autowired
    TransactionRepo transactionRepo;
    @Autowired
    ProductDbService productDbService;
    @Autowired
    private final AccountRepository accountRepository;

    public TransactionController(ProductDbService service, AccountRepository accountRepository) {
        this.service = service;
        this.accountRepository = accountRepository;
    }

    @GetMapping("/fetch")
    public ResponseEntity<List<Transaction>> getAllTransaction() {
        List<Transaction> products = service.getAllTransactions();
        return new ResponseEntity<List<Transaction>>(products, HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<Transaction> getProductById(@PathVariable("id") Long id) {
        Transaction product = service.findTransactById(id);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }

    @GetMapping("/getTransaction/{toAcct}")

    public ResponseEntity<List<Transaction>> getProductById(@PathVariable("toAcct") String toAcct) {
        String toRoutingNum = "9099791770";
        List<Transaction> transactionList = service.getTransactions(toAcct, toRoutingNum);
        return new ResponseEntity<>(transactionList, HttpStatus.OK);
    }

    @GetMapping("/findbalance/{id}")
    public ResponseEntity<Long> getBalanceById(@PathVariable("id") String id) {
        String routingNum = "883745004";

        long product = service.findAmountById(id, routingNum);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }

//    @PostMapping(value = "/deposit")
//    public ResponseEntity<Integer> depositFunds(@RequestParam("amount") long amount, @RequestParam("account") String account) {
//        // Process the depositForm object
//        long toAmount = amount;
//        String toAccount = account;
//        System.out.println("amount" + amount);
//        System.out.println("account" + account);
//
//        // Add your logic to handle the deposit here
//        String toRoute = "9099791700";
//        amount = toAmount;
//
//        service.addCredit(toAccount, toRoute, toAmount);
//        long balance = service.findAmountById(toAccount, "883745004");
//        log.info("balance+++, {}" + balance);
//        long credAmt = service.findAmountByCredId(toAccount, "883745004");
//        log.info("credAmt +++++" + credAmt);
//
//        long bal = balance + credAmt;
//        System.out.println(" balance " + bal);
//        log.info("balance++++++++, {}" + balance);
//        log.info("balance +++++" + bal);
//        int update = service.updateCredit(bal, toAccount);
        //
//        String toRoutingNum = "9099791770";
//        List<Transaction> transactions = service.getTransactions(toAccount, toRoutingNum);
//        Optional<Transaction> optLatestTransaction = transactions.stream()
//                .max(Comparator.comparing(Transaction::getTimestamp));
//        Transaction latestTransaction = optLatestTransaction.get();
//        UpdateObject object = new UpdateObject();
//        object.setAccount(latestTransaction.getFromAccountNum());
//        object.setAmount(credAmt);
//        HttpEntity<UpdateObject> request = new HttpEntity<>(object);
//        log.info("From Account  +++++" + object.getAccount());
//        log.info("Credited Amount  +++++" + object.getAmount());


//        String msurl = "http://localhost:6060/apiDebit/updateDbBalance";
//        ResponseEntity<Double> balanceAmount = restTemplate.exchange(msurl.trim(), HttpMethod.POST, request, Double.class);
//        //Integer finalBalanceAmt = Integer.valueOf(balanceAmount.getBody().intValue());
//        return new ResponseEntity<Integer>(latestTransaction.getAmount(), HttpStatus.OK);
//    }

//    @PostMapping(value = "/updateCrBalance", consumes = "application/json")
//    public ResponseEntity<?> updateCreditBalance(@RequestBody UpdateObject updateObject) throws JsonProcessingException {
//        ObjectMapper objectMapper = new ObjectMapper();
//        String json = objectMapper.writeValueAsString(updateObject);
//        UpdateObject transaction = objectMapper.readValue(json, UpdateObject.class);
//
//        String toAcct = transaction.getAccount().trim();
//        String toRoutingNum = "9099791700"; // Change if necessary
//        double creditAmount = updateObject.getAmount();
//
//        // Fetch the latest transaction for the account
//        List<Transaction> transactions = productDbService.getTransactions(toAcct, toRoutingNum);
//        Optional<Transaction> latestTransaction = transactions.stream()
//                .max(Comparator.comparing(Transaction::getTimestamp));
//
//        Transaction transactionDBObj = latestTransaction.orElse(null);
//
//        if (transactionDBObj != null) {
//            log.info("Current balance: {}", transactionDBObj.getAmount());
//        }

//        if (transactions.isEmpty()) {
//            return new ResponseEntity<>("Transaction history not found", HttpStatus.NOT_FOUND);
//        }
//
//        // Add the credited amount
//        productDbService.addCredit(toAcct, toRoutingNum, (long) creditAmount);
//        log.info("Credit record added successfully");
//
//        // Calculate the updated balance
//        double updatedBalance = transactionDBObj.getAmount() + creditAmount;
//        Integer finalBalance = (int) updatedBalance;
//
//        // Update the balance in the transaction record
//        int recordsUpdated = productDbService.updateCredit(finalBalance, toAcct);
//        log.info("Updated Transaction Details: {}", finalBalance);
//
//        return new ResponseEntity<>(updatedBalance, HttpStatus.CREATED);
//    }
@PostMapping("/createTransaction")
public ResponseEntity<Transaction> createTransaction(@RequestBody Transaction transaction) {
    log.info("Processing transaction: {}", transaction);

    // Assign a unique transaction ID
    transaction.setTransactionId(UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE);
    transaction.setTimestamp(Date.from(Instant.now()));
    transaction.setFromRoutingNum("0");
    transaction.setToRoutingNum("0");
    // Handle DEBIT & CREDIT correctly
    if ("CREDIT".equalsIgnoreCase(transaction.getPaymentType())) {
        transaction.setCreditedAmount(transaction.getAmount()); // FIXED: Set credit correctly
        transaction.setDebitedAmount(0.0);
    } else if ("DEBIT".equalsIgnoreCase(transaction.getPaymentType())) {
        transaction.setDebitedAmount(transaction.getAmount()); // FIXED: Set debit correctly
        transaction.setCreditedAmount(0.0);
    } else {
        log.error("Invalid transaction type: {}", transaction.getPaymentType());
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    Transaction savedTransaction = transactionRepo.save(transaction);
    log.info("Transaction created successfully: {}", savedTransaction);
    return new ResponseEntity<>(savedTransaction, HttpStatus.CREATED);
}

    @PostMapping("/updateCreditAmt")
    public ResponseEntity<String> updateCreditAmt(@RequestBody Map<String, Object> request) {
        String fromAccount = (String) request.get("fromAccount");
        String toAccount = (String) request.get("toAccount");
        Double creditAmount = Double.valueOf(request.get("amount").toString());

        log.info("Received credit request from {} to {}", fromAccount, toAccount);

        productDbService.addCreditRecord(fromAccount, toAccount, creditAmount);

        return new ResponseEntity<>("Amount credited successfully", HttpStatus.OK);
    }
    @PostMapping(value = "/updateDbBalance", consumes = "application/json")
    public ResponseEntity<?> updateDebitBalance(@RequestBody UpdateObject updateObject) throws JsonProcessingException {
        log.info("Received request: Amount={}, FromAccount={}, ToAccount={}",
                updateObject.getAmount(), updateObject.getFromAccount(), updateObject.getToAccount());

        log.info("Received full request object: {}", updateObject);

        // Ensure incoming object is not null
        if (updateObject == null || updateObject.getFromAccount() == null || updateObject.getToAccount() == null) {
            log.error("Invalid request payload: {}", updateObject);
            return new ResponseEntity<>("Invalid request payload", HttpStatus.BAD_REQUEST);
        }

        String fromAcctNum = updateObject.getFromAccount();
        String toAccountNum = updateObject.getToAccount();
        double debitAmount = updateObject.getAmount();

        log.info("Updating debit balance from account: {} to account : {} of amount: {}", fromAcctNum, toAccountNum, debitAmount);
        double updatedBalance = 0.0;
        Optional<Accounts> accountOpt = accountRepository.findByAccountNumber(fromAcctNum);
        if (accountOpt.isPresent()) {
            Accounts singleAccount = accountOpt.get();
            double accountBalance = singleAccount.getAccountBalance();

////            //condition to check the balance
//            if (accountBalance < debitAmount) {
//                throw new BalanceInsufficientException(HttpStatus.BAD_REQUEST.value(), "The user doesn't have balance to proceed");
//            }

            //Calculate the balance
            updatedBalance = accountBalance - debitAmount;
            //save balance to accounts
            accountRepository.updateAccountBalance(fromAcctNum, updatedBalance);

            Transaction debitTransaction = new Transaction();
            debitTransaction.setFromAccountNum(fromAcctNum);
            debitTransaction.setToAccountNum(toAccountNum);
            debitTransaction.setAmount(updatedBalance);
            debitTransaction.setDebitedAmount(debitAmount);
            debitTransaction.setTimestamp(new Date());
            debitTransaction.setPaymentType("DEBIT");
            debitTransaction.setCreditedAmount(0.0);
            debitTransaction.setToRoutingNum("0");
            debitTransaction.setFromRoutingNum("0");

            transactionRepo.save(debitTransaction);
            log.info("Debit transaction saved successfully: {}", debitTransaction);
        }
        // Step 3: Call the Credit Service
        try {
            RestTemplate restTemplate = new RestTemplate();
            String creditServiceUrl = "http://localhost:8081/apiDebit/updateCreditAmt"; // Update URL based on deployment

            // Create credit request payload
            Map<String, Object> creditRequest = new HashMap<>();
            creditRequest.put("fromAccount", fromAcctNum);
            creditRequest.put("toAccount", toAccountNum);
            creditRequest.put("amount", debitAmount);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(creditRequest, headers);

            ResponseEntity<String> creditResponse = restTemplate.exchange(creditServiceUrl, HttpMethod.POST, entity, String.class);

            if (creditResponse.getStatusCode() == HttpStatus.OK) {
                log.info("Credit successful for account: {}", toAccountNum);
            } else {
                log.error("Credit failed: {}", creditResponse.getBody());
            }
        } catch (Exception e) {
            log.error("Error while calling Credit Service: {}", e.getMessage());
        }

        return new ResponseEntity<>(updatedBalance, HttpStatus.OK);
    }
    @GetMapping("/getAllTransactions")
    public ResponseEntity<?> getAllTransactions() {
        List<Transaction> transactions = transactionRepo.findAll();

        if (transactions.isEmpty()) {
            log.warn("No transactions found.");
            return new ResponseEntity<>("No transactions found", HttpStatus.NOT_FOUND);
        }

        log.info("Fetched {} transactions", transactions.size());
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }

}