package org.example.example.controller;
import lombok.extern.slf4j.Slf4j;
import org.example.example.model.Accounts;
import org.example.example.repository.BankRepository;
import org.example.example.repository.TransactionRepo;
import org.example.example.service.AccountService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/accounts")
@Slf4j
public class AccountController {
    private static final Logger log = LoggerFactory.getLogger(AccountController.class.getName());

    private final AccountService accountService;
    @Autowired
    private BankRepository bankRepository;
    @Autowired
    private TransactionRepo transactionRepo;

    @Autowired
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @PostMapping("/save")
    public Accounts saveAccount(@RequestBody Accounts account) {
        log.info("Received request to save account: {}", account);
        //Check if account exists
        Accounts savedAccount = accountService.createOrUpdateAccount(
                account.getAccountNumber(),
                account.getAccountType(),
                String.valueOf(account.getUserId().longValue()),
                account.getAccountBalance()
        );
        log.info("Account saved successfully: {}", savedAccount);
        return savedAccount;
    }

    @PostMapping("/saveAll")
    public List<Accounts> saveAllAccounts(@RequestBody List<Accounts> accounts) {
        log.info("Received request to save multiple accounts: {}", accounts);
        List<Accounts> savedAccounts = accountService.saveAllAccounts(accounts);
        log.info("All accounts saved successfully.");
        return savedAccounts;

    }

    @GetMapping("/fetchAccountDetails/{user_name}")
    public ResponseEntity<?> fetchAccountDetailsByUsername(@PathVariable String user_name) {
        log.info("Fetching account details for username: {}", user_name);

        List<String> accountNumbers = accountService.getAccountsByUsername(user_name);

        if (accountNumbers.isEmpty()) {
            log.warn("No accounts found for username: {}", user_name);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No accounts found for username: " + user_name);
        }

        // Format the response as "Account Number: <value>"
        List<Map<String, String>> formattedResponse = accountNumbers.stream()
                .map(accNum -> Map.of("Account Number", accNum))
                .collect(Collectors.toList());

        return ResponseEntity.ok(formattedResponse);
    }
}
