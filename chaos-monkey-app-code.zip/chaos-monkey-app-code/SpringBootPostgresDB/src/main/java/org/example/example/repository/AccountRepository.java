package org.example.example.repository;
import jakarta.transaction.Transactional;
import org.example.example.model.Accounts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Accounts, String> {

    Optional<Accounts> findByAccountNumber(String fromAcctNum);

    @Transactional
    @Modifying
    @Query(value = "UPDATE accounts SET account_balance = ?2 WHERE account_number = ?1", nativeQuery = true)
    int updateAccountBalance(String toAccount, double updatedBalance);

    @Query(value = "SELECT a.account_number FROM accounts a " +
        "JOIN users u ON a.user_id = u.user_id " +
        "WHERE u.username = ?1",
        nativeQuery = true)
    Optional<String> getAccountNumberByUserName(String username);

    @Query(value = "SELECT a.account_number FROM accounts a JOIN users u ON a.user_id = u.user_id WHERE  u.username = ?1", nativeQuery = true)
    List<String> findAccountNumbersByUsername(@Param("username") String username);

}