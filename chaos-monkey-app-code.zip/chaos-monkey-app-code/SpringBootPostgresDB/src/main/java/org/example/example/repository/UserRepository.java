package org.example.example.repository;



import org.example.example.model.Transaction;
import org.example.example.model.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<Users, Long> {

List<Transaction> findTransactionsByUsername(String username); // Correct field name

    Optional<Users> findByUsername(String username);

}
