package org.example.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import jakarta.persistence.*;
import lombok.*;
import java.util.Date;

/**
 * Defines a banking transaction.
 *
 * Timestamped at object creation time.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TRANSACTIONS")
public final class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TRANSACTION_ID")
    private long transactionId;

    @Column(name = "FROM_ACCT")
    @JsonProperty("fromAccountNum")
    private String fromAccountNum;

    @Column(name = "FROM_ROUTE")
    @JsonProperty("fromRoutingNum")
    private String fromRoutingNum;

    @Column(name = "TO_ACCT")
    @JsonProperty("toAccountNum")
    private String toAccountNum;

    @Column(name = "TO_ROUTE")
    @JsonProperty("toRoutingNum")
    private String toRoutingNum;

    @Column(name = "AMOUNT")
    @JsonProperty("amount")
    private Double amount;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "TIMESTAMP")
    @JsonProperty("timestamp")
    private Date timestamp;

    @Column(name = "CREDITED_AMOUNT")
    private Double creditedAmount;

    @Column(name = "DEBITED_AMOUNT")
    private Double debitedAmount;

    @Column(name = "PAYMENT_TYPE")
    private String paymentType;


    public long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(long transactionId) {
        this.transactionId = transactionId;
    }

    public String getFromAccountNum() {
        return fromAccountNum;
    }

    public void setFromAccountNum(String fromAccountNum) {
        this.fromAccountNum = fromAccountNum;
    }

    public String getFromRoutingNum() {
        return fromRoutingNum;
    }

    public void setFromRoutingNum(String fromRoutingNum) {
        this.fromRoutingNum = fromRoutingNum;
    }

    public String getToAccountNum() {
        return toAccountNum;
    }

    public void setToAccountNum(String toAccountNum) {
        this.toAccountNum = toAccountNum;
    }

    public String getToRoutingNum() {
        return toRoutingNum;
    }

    public void setToRoutingNum(String toRoutingNum) {
        this.toRoutingNum = toRoutingNum;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public Double getCreditedAmount() {
        return creditedAmount;
    }

    public void setCreditedAmount(Double creditedAmount) {
        this.creditedAmount = creditedAmount;
    }

    public Double getDebitedAmount() {
        return debitedAmount;
    }

    public void setDebitedAmount(Double debitedAmount) {
        this.debitedAmount = debitedAmount;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPaymentType() {
        return paymentType;
    }

    private static final double CENTS_PER_DOLLAR = 100.0;

    @Override
    public String toString() {
        return String.format("%s -> $%.2f -> %s",
                fromAccountNum, amount / CENTS_PER_DOLLAR, toAccountNum);
    }
}
