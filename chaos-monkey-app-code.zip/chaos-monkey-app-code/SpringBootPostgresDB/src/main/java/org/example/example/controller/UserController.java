package org.example.example.controller;


import org.example.example.model.*;
import org.example.example.repository.AccountRepository;
import org.example.example.repository.BankRepository;
import org.example.example.repository.TransactionRepo;
import org.example.example.repository.UserRepository;
import org.example.example.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/users")
//@CrossOrigin(origins = "http://localhost:63342")
public class UserController {
    private static final Logger log = LoggerFactory.getLogger(UserController.class.getName());

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private UserService userService;
    @Autowired
    private BankRepository bankRepository;
    @Autowired
    TransactionRepo transactionRepo;

    @Value("${pageable.page}")
    private int page;

    @Value("${pageable.size}")
    private int size;

    @GetMapping("/getUsers")
    public ResponseEntity<List<Users>> getAllUsers() {
        List<Users> usersList = userRepository.findAll();  // Use Users instead of User
        return new ResponseEntity<>(usersList, HttpStatus.OK);
    }

    @PostMapping("/createUser")
    public ResponseEntity<Users> createUser(@RequestBody Users users) {
        Users savedUser = userRepository.save(users);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

    @PostMapping("/validateUser")
    public ResponseEntity<Boolean> validateUser(@RequestParam String username, @RequestParam String password) {
        boolean isValid = false;
        try {
            isValid = userService.validateUser(username, password);
            if (isValid) {
                log.info("User {} is valid", username);
                return new ResponseEntity(isValid, HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Invalid login attempt for user {}", username);
            return new ResponseEntity(isValid, HttpStatus.UNAUTHORIZED);
        }
        return new ResponseEntity(isValid, HttpStatus.UNAUTHORIZED);
    }

    @GetMapping("/getAllTransactions/{username}")
    public ResponseEntity<?> getAllTransactions(@PathVariable String username) {
        String accountNumber = accountRepository.getAccountNumberByUserName(username)
                .orElseThrow(() -> new RuntimeException("Account number not found for username: " + username));
        // Fetching latest 10 transactions
        Pageable pageable = PageRequest.of(page, size);
//        List<Transaction> transactions=transactionRepo.findByFromAccountNum(accountNumber);
        List<Transaction> transactions = transactionRepo.findByFromAccountNumOrToAccountNumOrderByTimestampDesc(accountNumber, accountNumber, pageable);

        if (transactions == null || transactions.isEmpty()) {
            log.warn("No transactions found for username: {}", username);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No transactions found for username: " + username);
        }
        List<TransactionHistory> transactionHistoryList = transactions.stream().map(transaction -> {
            //check the payment type and fetch the bank based on from or to account
            BankDetailsDTO bankDetailsDTO = null;
            List<Object[]> results = new ArrayList<>();
            String beneAccountNum = "";
            if ("credit".equalsIgnoreCase(transaction.getPaymentType())) {
                results = bankRepository.getBankDetailsByToAccountNum(transaction.getFromAccountNum());
                beneAccountNum = transaction.getFromAccountNum();
            } else if ("debit".equalsIgnoreCase(transaction.getPaymentType())){
                results = bankRepository.getBankDetailsByToAccountNum(transaction.getToAccountNum());
                beneAccountNum = transaction.getToAccountNum();
            }
            if (!results.isEmpty()) {
                Object[] row = results.get(0);
                bankDetailsDTO = new BankDetailsDTO((String) row[0], (String) row[1], (String) row[2]);
              log.info("Bank details fetched: {}", bankDetailsDTO);
/*            if (bankDetailsDTO == null) {
                //log.warn("No bank details found for toAccountNum: {}", toAccountNum);
                bankDetailsDTO = new BankDetailsDTO();
            }*/
            }
            // Map bank details to TransactionHistory object
            TransactionHistory history = new TransactionHistory();
            history.setTransactionId(transaction.getTransactionId());
            history.setBeneAccountNum(beneAccountNum);
            history.setAmount(transaction.getAmount());
            history.setPaymentType(transaction.getPaymentType());
            history.setTimestamp(transaction.getTimestamp().toInstant());
//            history.setBankName(bankDetailsDTO.getBank_name() != null ? bankDetailsDTO.getBank_name() : "N/A");
            history.setBankName(bankDetailsDTO != null && bankDetailsDTO.getBank_name() != null ?
                    bankDetailsDTO.getBank_name() : "N/A");
            history.setBankIfsc(bankDetailsDTO != null && bankDetailsDTO.getBank_ifsc() != null ? bankDetailsDTO.getBank_ifsc() : "N/A");
            history.setAccountHolderName(bankDetailsDTO != null && bankDetailsDTO.getAccount_holder_name() != null ? bankDetailsDTO.getAccount_holder_name() : "N/A");
            history.setDebitedAmount(transaction.getDebitedAmount());
            history.setCreditedAmount(transaction.getCreditedAmount());
            return history;
        }).collect(Collectors.toList());

        if (transactionHistoryList.isEmpty()) {
            log.warn("No transaction history found for username: {}", username);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No transaction history found for username: " + username);
        }

        return ResponseEntity.ok(transactionHistoryList);
    }
}
