package org.example.example.repository;


import org.example.example.model.Transaction;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
public interface TransactionRepo extends JpaRepository<Transaction, Long> {
    @Query(value = "(SELECT SUM(AMOUNT) FROM TRANSACTIONS t "
            + "     WHERE (TO_ACCT = ?1 AND TO_ROUTE = ?2))",
            nativeQuery = true)
    Long findBalance(String accountNum, String routeNum);

    @Modifying
    @Transactional
    @Query(value = "UPDATE TRANSACTIONS t SET amount = :amount WHERE TO_ACCT = :toAcct", nativeQuery = true)
    int updateCredit(@Param("amount") Long amount, @Param("toAcct") String fromAcct);


    @Modifying
    @Transactional
    @Query(value = "UPDATE TRANSACTIONS t SET amount = :amount WHERE TO_ACCT = :toAcct", nativeQuery = true)
    int updateDebit(@Param("amount") Long amount, @Param("toAcct") String toAcct);

    @Query(value = "SELECT * FROM  TRANSACTIONS WHERE TO_ACCT = :toAcct ORDER BY timestamp DESC  LIMIT 1", nativeQuery = true)
    Transaction getTransaction(@Param("toAcct") String toAcct);

    List<Transaction> findByFromAccountNumOrToAccountNumOrderByTimestampDesc(String fromAccountNum, String toAccountNum, Pageable pageable);
}
