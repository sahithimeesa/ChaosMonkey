package org.example.example.service;


import org.example.example.controller.TransactionController;
import org.example.example.model.*;
import org.example.example.repository.AccountRepository;
import org.example.example.repository.TransactionRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ProductDbService {
    private static final Logger log = LoggerFactory.getLogger(TransactionController.class.getName());

    @Autowired
    private final TransactionRepo transactionRepo;
    @Autowired
    private final AccountRepository accountRepository;

    @Autowired
    public ProductDbService(TransactionRepo transactionRepo,
                            AccountRepository accountRepository) {
        this.transactionRepo = transactionRepo;
        this.accountRepository = accountRepository;
    }

    public Transaction addProduct(Transaction transaction) {
        return transactionRepo.save(transaction);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepo.findAll();
    }

    public List<Transaction> getTransactions(String toAcct, String toRoutingNum) {
        return transactionRepo.findAll();
    }

    public Transaction findTransactById(Long id) {
        return transactionRepo.findById(id).orElseThrow(() -> new TransactionNotFoundException("Transaction with id " + id + " not found!"));
    }

    public Long findAmountById(String id, String routingNum) {
        routingNum = "883745004";
        return transactionRepo.findBalance(id, routingNum);
    }

    public void deleteTransaction(Long id) {
        transactionRepo.deleteById(id);
    }

    public int updateCredit(long amnt, String routingNum) {
        return transactionRepo.updateCredit(amnt, routingNum);
    }


//    public PaymentResponse depositFunds(PaymentRequest request) {
//        // Validate deposit amount
//        if (request.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
//            log.error("Invalid deposit amount: {}", request.getAmount());
//            return new PaymentResponse("FAILED", "Invalid amount");
//        }
//
//        // Simulate deposit processing
//        boolean success = processDeposit(request);
//
//        // Return response
//        if (success) {
//            log.info("Deposit processed successfully for account: {}", request.getReceiverAccount());
//
//            // Record the transaction in PostgreSQL
//            CreditTransaction creditTransaction = new CreditTransaction();
//            creditTransaction.setFromAccountNum("SYSTEM"); // System credits the amount
//            creditTransaction.setToAccountNum(request.getReceiverAccount());
//            creditTransaction.setAmount(request.getAmount().doubleValue());
//            creditTransaction.setTimestamp(new Date()); // Set current timestamp
//            creditTransaction.setPaymentType("DEPOSIT");
//
//            // Save the deposit transaction
//            creditTransactionRepository.save(creditTransaction);
//            log.info("Deposit transaction saved: {}", creditTransaction);
//
//            return new PaymentResponse("SUCCESS", "Funds deposited successfully");
//        } else {
//            log.error("Deposit processing failed for account: {}", request.getReceiverAccount());
//            return new PaymentResponse("FAILED", "Deposit processing failed");
//        }
//    }
//
//    private boolean processDeposit(PaymentRequest request) {
//        // Simulating deposit success with an 80% success rate
//        return Math.random() > 0.2;
//    }

    public void addCreditRecord(String fromAccount, String toAccount, Double creditAmount) {
        log.info("Crediting amount {} from account {} to account {}", creditAmount, fromAccount, toAccount);

        double updatedBalance = 0.0;
        Optional<Accounts> accountOpt = accountRepository.findByAccountNumber(toAccount);
        if(accountOpt.isPresent()) {
            Accounts singleAccount = accountOpt.get();
            double accountBalance = singleAccount.getAccountBalance();
            //Calculate the balance
            updatedBalance = accountBalance + creditAmount;
            //save balance to accounts
            accountRepository.updateAccountBalance(toAccount, updatedBalance);
        }

        // Create a new credit transaction
        Transaction creditTransaction = new Transaction();
        creditTransaction.setFromAccountNum(fromAccount);
        creditTransaction.setToAccountNum(toAccount);
        creditTransaction.setAmount(updatedBalance);
        creditTransaction.setCreditedAmount(creditAmount);
        creditTransaction.setDebitedAmount(0.0);
        creditTransaction.setFromRoutingNum("0");
        creditTransaction.setToRoutingNum("0");
        creditTransaction.setTimestamp(new Date());
        creditTransaction.setPaymentType("CREDIT");

        // Add the credit transaction in PostgreSQL
        transactionRepo.save(creditTransaction);

        log.info("Credit transaction saved successfully: {}", creditTransaction);
    }
}


