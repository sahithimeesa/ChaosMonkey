package org.example.example.service;


import jakarta.annotation.PostConstruct;
import org.example.example.model.Users;
import org.example.example.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


import java.util.Arrays;
import java.util.List;
import java.util.Optional;



@Service

public class UserService {
    private static final Logger log = LoggerFactory.getLogger(UserService.class);  // Manually creating logger

    @Autowired
    private UserRepository userRepository;

    @Value("${authorized.users}")
    private List<String> authorizedUsers;

    @PostConstruct
    public void initDatabase() {
        if (userRepository.count() == 0) {
            for (String username : authorizedUsers) {
                Optional<Users> userOpt = userRepository.findByUsername(username);
                if(userOpt.isPresent()) {
                    String password = username + "123"; // Dynamically setting password
                    Users user = new Users(username, password);
                    userRepository.save(user);
                    log.info("User created: {} with password: {}", username, password);
                }
            }
        } else {
            log.info("Users already exist in the database.");
        }
    }

    public boolean validateUser(String username, String password) {
        Optional<Users> userOpt = userRepository.findByUsername(username);

        if (userOpt.isPresent()) {
            Users user = userOpt.get();
            if (user.getPassword().equals(password)) {
                return true; // Valid user
            }
        }

        throw new RuntimeException("Invalid username or password");
    }

}